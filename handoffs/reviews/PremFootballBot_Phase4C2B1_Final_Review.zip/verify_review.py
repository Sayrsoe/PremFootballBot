"""Offline exact-source/math audit; default also runs complete regressions.
Use --skip-tests for hash/tree/math replay only. Optional --delivery-zip PATH
prints the delivery tree obtained by adding just that ZIP to implementation.
"""
from contextlib import ExitStack
import hashlib,json,math
from pathlib import Path
import subprocess,sys
from unittest.mock import patch

root=Path(__file__).resolve().parent
manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_bytes())
for name,sha in manifest.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
m=json.loads((root/'evidence/SOURCE_MANIFEST.json').read_bytes())
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def tree(entries):
    folders={}
    for e in entries:
        parts=e['path'].split('/');d=folders
        for part in parts[:-1]:d=d.setdefault(part,{})
        d[parts[-1]]=(e['mode'],e['git_blob'])
    def encode(d):
        raw=b''
        for name,value in sorted(d.items(),key=lambda item:(item[0]+('/' if isinstance(item[1],dict) else '')).encode('utf8')):
            mode,sha=('40000',encode(value)) if isinstance(value,dict) else value
            raw+=mode.encode()+b' '+name.encode('utf8')+b'\0'+bytes.fromhex(sha)
        return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    return encode(folders)
for folder,entries,expected in [('source',m['files'],m['implementation_tree']),('baseline',m['base_files'],m['base_tree'])]:
    actual={p.relative_to(root/folder).as_posix() for p in (root/folder).rglob('*') if p.is_file()}
    assert actual=={e['path'] for e in entries},folder
    for e in entries:
        raw=(root/folder/e['path']).read_bytes()
        assert len(raw)==e['bytes'] and blob(raw)==e['git_blob'],e['path']
        assert hashlib.sha256(raw).hexdigest()==e['sha256'],e['path']
    assert tree(entries)==expected
for name in m['protected_unchanged']:assert (root/'source'/name).read_bytes()==(root/'baseline'/name).read_bytes(),name
for label,sha,expected_tree in [('BASE',m['base_commit'],m['base_tree']),('IMPLEMENTATION',m['implementation_commit'],m['implementation_tree'])]:
    raw=(root/'evidence'/(label+'_COMMIT.txt')).read_bytes()
    assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha
    assert raw.splitlines()[0]==('tree '+expected_tree).encode()
assert ('parent '+m['base_commit']).encode() in (root/'evidence/IMPLEMENTATION_COMMIT.txt').read_bytes().splitlines()
if '--delivery-zip' in sys.argv:
    path=Path(sys.argv[sys.argv.index('--delivery-zip')+1])
    entries=m['files']+[{'path':m['delivery_addition'],'mode':'100644','git_blob':blob(path.read_bytes())}]
    print('Delivery tree from source plus provided ZIP:',tree(entries),flush=True)
print('Verified',len(m['files']),'exact source blobs and',len(m['protected_unchanged']),'protected files; base/source commits and trees verified.',flush=True)
if '--skip-tests' not in sys.argv:
    subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-v'],cwd=root/'source',check=True)
sys.path.insert(0,str(root/'source'))
from premfootballbot import weighted_poisson as w
from tests.test_weighted_poisson import varied_rows,synthetic_recovery_case
expected_model=(root/'evidence/INVENTED_EXAMPLE_MODEL.json').read_bytes()
expected_recovery=(root/'evidence/SYNTHETIC_RECOVERY_MODEL.json').read_bytes()
rows=varied_rows();recovery,truth=synthetic_recovery_case()
forbidden=('real_epl_training._fit_rows','real_epl_training._objective','real_epl_training._derivatives','real_epl_training._solve',
    'real_epl_training.fit_real_epl','chronological_epl.fit_development','chronological_epl.evaluate_holdout',
    'chronological_epl.forecast_holdout','completed_epl.import_completed_epl','result_evaluation.score_1x2')
with ExitStack() as stack:
    for name in forbidden:stack.enter_context(patch('premfootballbot.'+name,side_effect=AssertionError(name)))
    for name in ('socket.socket','urllib.request.urlopen','builtins.open','time.time'):
        stack.enter_context(patch(name,side_effect=AssertionError(name)))
    stack.enter_context(patch.object(Path,'read_bytes',side_effect=AssertionError('file read')))
    stack.enter_context(patch.object(Path,'write_bytes',side_effect=AssertionError('file write')))
    model=w.fit_invented_matches(rows,w.WeightedConfig(half_life_days=180))
    assert w.verify_weighted_fit(model,rows)
    recovered=w.fit_invented_matches(recovery,w.WeightedConfig(half_life_days=180))
    # Exact diagnostic byte replay is explicitly same-runtime only. A different
    # math runtime may need independent numerical review; this is not model auth.
    assert w.weighted_fit_json(model)==expected_model,'Example differs; inspect runtime and numerical audit, do not accept arbitrary hashes'
    assert w.weighted_fit_json(recovered)==expected_recovery,'Recovery differs; inspect runtime/math, do not weaken checks'
    theta=(.2,-.1,.15,-.25,.1,-.1,.3,-.2);weights=(1.,.75,.5,.3,.125,.01)
    e=w.evaluate_objective(rows,weights,theta)
    for i in range(8):
        p=list(theta);n=list(theta);p[i]+=1e-5;n[i]-=1e-5
        a,b=w.evaluate_objective(rows,weights,tuple(p)),w.evaluate_objective(rows,weights,tuple(n))
        assert abs((a.objective-b.objective)/2e-5-e.gradient[i])<2e-8
        for j in range(8):assert abs((a.gradient[j]-b.gradient[j])/2e-5-e.hessian[j][i])<2e-8
print('Invented-only replay, synthetic recovery, finite-difference mathematics and denied runtime integrations passed.',flush=True)
print('No model authorization, real-data study, B2, predictions or merge. Independent review required.')
