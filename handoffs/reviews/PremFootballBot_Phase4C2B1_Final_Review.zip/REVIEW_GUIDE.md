# Phase 4C2-B1 final independent-review handoff

Repository: https://github.com/Sayrsoe/PremFootballBot
Draft branch: codex/phase4c2b1-weighted-poisson
Base: e055e4df76aad0d982e6524ff147fecf4b5e4024
Base tree: eeb52ee26a8e7c0bf3231fef0fba1051ee25e5e9
Implementation source commit: de5c9ff680dd58cafe8fd76d627c4ef449386e6c
Implementation source tree: 012402b8e2dea4e9f0c7c5d569ef384cb0b17a24

Final GitHub PR and download links, delivery head/tree and ZIP checksum are in
its PR body and the owner's delivery response. The delivery-only child commit
adds exactly handoffs/reviews/PremFootballBot_Phase4C2B1_Final_Review.zip. This
package pins ALL implementation source except that ZIP itself, avoiding an
impossible self-containing/self-hashing archive. No code changes in delivery.

Read source/handoffs/CODEX_PHASE4C2B1_IMPLEMENTATION_REPORT.md for full scope,
research pins/licenses, equations/derivations, APIs/example, numerical bounds,
tests, integrity restrictions, source rights and limitations. This is an
engineering self-review package, not a claim that independent review occurred.

## Actual tests and evidence

Windows CPython3.12.14, baseline743 passed24.629s; working781 passed26.114s.
Committed-export full: 781 passed in 25.086s.
Committed-export focused: 38 passed in 0.124s.
Commands: python -B -m unittest discover -s tests -v;
python -B -m unittest tests.test_weighted_poisson -v.
No failed test run. No Linux/3.13/other runtime, remote CI, linter or type checker
execution claimed. All46 Python files pass3.10 grammar parsing, not runtime.
Required pre-existing regressions include prior fixture fitting/scoring; new B1
math tests and code use only invented data, no new real-EPL fit/evaluation.

Gradient FD maximum error 1.2181577968561896e-10; Hessian from
analytic gradient error 1.4578205309589976e-10; scalar
mixed second-difference error 6.768064952922259e-08.
Uniform objective/gradient/Hessian differences exactly zero, including constants
and fixed ridge. Synthetic recovery2400 invented matches, max parameter error
0.04625217302004825, ESS 2065.1964557604106.
This is numerical verification, not a football predictive-performance claim.

All84 source files match Git blobs/SHA256; all80 protected baseline files unchanged.
The binary patch was applied to a separate exact baseline checkout and all84
resulting files matched source byte-for-byte. Original fixtures/authorizations/
synthetic, prospective, real/retrospective, chronology and cold-start code unchanged.

## Source inventory and offline audit

Implementation changes:
- README.md
- handoffs/CODEX_PHASE4C2B1_IMPLEMENTATION_REPORT.md
- premfootballbot/weighted_poisson.py
- tests/test_weighted_poisson.py
Delivery addition: the single final review ZIP, no other changes.

source/ contains the COMPLETE exact implementation tree, not partial snippets.
baseline/ contains the exact approved base for offline comparison/patch replay.
implementation.patch is the feature commit patch against that baseline.
evidence/SOURCE_MANIFEST.json includes complete source/base Git/SHA256 inventory,
protected files, changed files and delivery contract. Raw commit objects prove
Git base/implementation identities and tree hashes. TEST_ENVIRONMENT.json and
verbose logs state actual commands/results. MATH_VERIFICATION.json and the two
invented example artifacts preserve quantitative verification and diagnostics.
PACKAGE_MANIFEST.json hashes every package file except itself (external ZIP
checksum/Git blob covers the package). No credentials, prompt, approval record,
planning/scratch/packaging scripts or intermediate ZIP are included.

Run python -B verify_review.py offline. It verifies package/files/Git trees,
runs all regressions and recomputes invented artifacts/math with forbidden
real-source/fit/score/network/files/clock integrations mocked to raise.
--skip-tests skips only the regression invocation, preserving integrity/math
replay. To reconstruct the delivery tree from the exact downloaded ZIP, also
pass --delivery-zip path/to/PremFootballBot_Phase4C2B1_Final_Review.zip and compare
the printed tree with GitHub's delivery head tree. It must equal source plus ZIP.

For independent patch replay: copy baseline/ to an empty disposable directory,
git init there, then git -c core.autocrlf=false apply /absolute/path/implementation.patch.
Compare every resulting file with the source manifest. Source code uses no third-
party dependency; raw weights, positive ridge and strict numerical fail-closed
rules are declared, never empirically tuned. Test data are invented toy identities.

Limits: numerical laboratory only, no source authorization/real-data adapter,
no historical fold or embargo integration, no half-life winner, bounded dense
solver, finite iteration/line-search/conditioning failures, same-runtime exact
artifact replay. Invented markers cannot authenticate arbitrary caller facts.
ESS is concentration, not power. No accuracy/calibration/ROI/profitability claim.
Do not fit/score real matches or select using exposed2025–26. Keep draft; independent
review and explicit owner approval before merge. No B2, deployment or predictions.
